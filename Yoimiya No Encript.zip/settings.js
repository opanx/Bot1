// RECODE BY DINZ
/////////////////
const chalk = require("chalk")
const fs = require("fs")
//aumto presence update
global.autoTyping = false //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = true //auto block 212 (true to on, false to off)
global.wlcm = true
global.autokickmorroco = true //auto kick 212 (true to on, false to off) 
global.antispam = false//auto kick spammer (true to on, false to off)
//////////////////////////////////////////////////////////////////////////////////
//BATAS//
//=========UBAH BAGIAN THUMBNAIL MENU & ALLMENU==========//
global.gif = fs.readFileSync('./data/image/yoimiya.mp4'), // BISA JUGA DI BAGIAN DATA/IMAGE/YOIMIYA.MP4
global.thumbnail = 'https://img3.teletype.in/files/20/47/2047944a-d1a1-4b06-9d73-20b98779a96f.jpeg', //THUMB MENU KALIAN
global.musikmenu = 'https://files.catbox.moe/n85z9t.mp3' //THUMB MUSIK KALIAN
global.de4you = 'https://files.catbox.moe/jsv33h.jpg', //THUMB MENU button KALIAN
/////////////////////////////////////////////////////////////////////////////////
//BATAS//
//////////////////////SETTING TAMPILAN MENU KALIAN//////////////////
global.ig = 'mhd_danil_panjaitan' //NAMA IG LU
global.yt = 'DE4YOU YT Projects' //NAMA YT LU, KALO GADA GAUSAH DIISI
global.ttowner = 'DE4YOU YTprojects' //NAMA TIKTOK LU
global.ownername = '✨️ DE4YOU YT Projects ✨️' //NAMA LU
global.owner = ['6287778002663'] // SETTING JUGA DI FOLDER DATABASE 
global.ownernomer = '6287778002663' // NOMOR LU
global.socialm = 'GitHub: -'
global.location = 'Indonesia' 
global.nameCreator = 'DE4YOU YT | nilOffc'
/////////////////////////////////////////////////////////////////////////////////
//BATAS//
//=================SETTING PAYMENT KALIAN===================\\
global.nodana = '6282262360515' // KOSONG KAN JIKA TIDAK ADA
global.nogopay = 'no' // KOSONG KAN JIKA TIDAK ADA 
global.noovo = 'no' // KOSONG KAN JIKA TIDAK ADA
/////////////////////////////////////////////////////////////////////////////////
//BATAS//
//==============SETTING PAYMENT NAME=======================\\
global.andana = '' // KOSONG KAN JIKA TIDAK ADA
global.angopay = '' // KOSONG KAN JIKA TIDAK ADA
global.anovo = '' // KOSONG KAN JIKA TIDAK ADA
//////////////////////////////////////////////////////////////////////////////////
//BATAS//
//==================SETTING BOT===========================\\
global.botname = "ʏᴏɪᴍɪʏᴀ ᴀssɪsᴛᴇɴᴛ" //NAMA BOT LU
global.ownernumber = '6287778002663' //NOMOR LU
global.botnumber = '6287778002663' //NOMOR LU
global.ownername = 'DE4YOU YT' //NAMA LU
global.idSaluran = "120363402330405118@newsletter"//ID SALURAN LU
global.idch = "120363402330405118@newsletter"//ID SALURAN LU
global.namaSaluran = "DE4YOU YT" //NAMA SALURAN LU
global.linkSaluran = "https://whatsapp.com/channel/0029Vb6YAhHDZ4LhEHIciq0s"//NAMA SALURAN LU
global.ownerNumber = ["6287778002663@s.whatsapp.net"] //NOMORLU
global.ownerweb = ""//WEB LU//OPSIONAL
global.websitex = ""//OPSIONAL
global.wagc = "https://chat.whatsapp.com/F7DTXOws6Wa1zVTFgIk8P5"//GRUP LU
global.saluran = "https://whatsapp.com/channel/0029Vb6YAhHDZ4LhEHIciq0s"//SALURAN LU
global.themeemoji = '🪀'
global.wm = "DE4YOU YT"//WM LU
global.botscript = 'BELI KONTOL' //script link//OPSIONAL
global.packname = "DE4YOU YT"//PACKNAME BEBAS 
global.author = "\n\nCreate by DE4YOU YT|Yoimiya-Ai\n Dev : DE4YOU YT || DE4YOU YT"//AUTHOR BEBAS
global.creator = "6287778002663@s.whatsapp.net" // NOMOR LU
/////////////////////////////////////////////////////////////////////////////////
//BATAS//
//================== CPANEL FITUR ==========================\\
global.domain = '-' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = '-' // Isi Apikey Plta Lu
global.capikey = '-' // Isi Apikey Pltc Lu
/////////////////////////////////////////////////////////////////////////////////
//BATAS//
///////////////////Server create panel egg pm2 ///////////////////////
global.apikey2 = '-' // Isi Apikey Plta Lu
global.capikey2 = '-' // Isi Apikey Pltc Lu
global.domain2 = '-' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah
global.eggsnya2 = '15' // id eggs yang dipakai
global.location2 = '1' // id location
/////////////////////////////////////////////////////////////////////////////////
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
/////////////////////////////////////////////////////////////////////////////////
//BATAS//
/////////////////////////////////////////////////////////////////////////////////
global.mess = {
wait: "*_ᴛᴜɴɢɢᴜ sᴇʙᴇɴᴛᴀʀ ʏᴀ ᴋᴀᴋ._*",
   success: "sᴜᴋsᴇs ᴋᴀᴋ",
   on: "sᴜᴅᴀʜ ᴀᴋᴛɪғ", 
   off: "sᴜᴅᴀʜ ᴏғғ",
   query: {
       text: "ᴛᴇᴋs ɴʏᴀ ᴍᴀɴᴀ ᴋᴀᴋ ?",
       link: "ʟɪɴᴋ ɴʏᴀ ᴍᴀɴᴀ ᴋᴀᴋ ?",
   },
   error: {
       fitur: "ᴍᴏʜᴏɴ ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ᴇʀᴏʀ sɪʟᴀʜᴋᴀɴ ᴄʜᴀᴛ ᴅᴇᴠᴇʟᴏᴘᴇʀ ʙᴏᴛ ᴀɢᴀʀ ʙɪsᴀ sᴇɢᴇʀᴀ ᴅɪᴘᴇʀʙᴀɪᴋɪ",
   },
   only: {
       group: " ʏᴀʜ ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴅᴀʟᴀᴍ ɢʀᴏᴜᴘ",
       private: "ʏᴀʜ ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴅᴀʟᴀᴍ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ",
       owner: "ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ sᴀᴍᴀ ᴏᴡɴᴇʀ ʙᴏᴛ",
       admin: "ᴍᴀᴀғ ᴋᴀᴋ ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ sᴀᴍᴀ ᴏᴡɴᴇʀ ʙᴏᴛ",
       badmin: "ᴍᴀᴀғ ᴋᴀᴋ ᴋᴀʏᴀ ɴʏᴀ ᴋᴀᴋᴀᴋ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ғɪᴛᴜʀ ɪɴɪ ᴅɪ ᴋᴀʀᴇɴᴀᴋᴀɴ ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ",
       premium: "ᴍᴀᴀғ ᴋᴀᴍᴜ ʙᴇʟᴏᴍ ᴍᴇɴᴊᴀᴅɪ ᴜsᴇʀ ᴘʀᴇᴍɪᴜᴍ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴘʀᴇᴍɪᴜᴍ sɪʟᴀᴋᴀɴ ʙᴇʟɪ ᴅɪ ᴏᴡɴᴇʀ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ ᴋᴇᴛɪᴋ  .ᴏᴡɴᴇʀ",
   }
}
//========================================\\
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.prefix = ['.']
global.sessionName = 'de4you' // Jangan di ubah takut nanti error
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
